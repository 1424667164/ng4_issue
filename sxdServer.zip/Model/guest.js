const medoo = require("./model.js");

module.exports = {
    async push(guest) {
        if(!guest.name && !guest.phone && !guest.value){
            return false;
        }
        let res = await medoo.insert('guests', guest);
        return res;
    }
}