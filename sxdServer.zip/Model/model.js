const Medoo = require('./medoo');
const medoo = new Medoo({
    host: "127.0.0.1",
    database: "sxd",
    user: "root",
    password: "04140906",
    port: 3306,
    debug_mode: true
});

medoo.init = async function () {
    await medoo.setup(); 
}
module.exports = medoo;
