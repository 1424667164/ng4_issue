// import Exceptions from "../Lib/exceptions";
const Router = require('../engine').Router;

module.exports = class User {
    @Router({
        path: '/user/login',
        method: 'POST'
    })
    async login(ctx, next) {
        let user = ctx.request.fields;
        if (!user.name) {
            throw Exceptions.user.without_name;
        }
        await next(); 
    }

    @Router({
        path: '/user/logout',
        method: 'GET'
    })
    async logout(ctx, next) {
        ctx.body.message += 'logout ' + ctx.request.query.name;
        console.log(ctx.request.fields);
        await next();
    }
}