const cms = require("../Lib/cms");
const email = require("../Lib/email");

// import Exceptions from "../Lib/exceptions";
const Router = require('../engine').Router;

module.exports = class User {
    @Router({
        path: '/push',
        method: 'POST'
    })
    async push(ctx, next) {
        try {
            let guest = ctx.request.fields;
            let res = await ctx.model.guest.push(guest);
            if (res !== false) {
                ctx.body.status = true;
                ctx.body.message = "Apply success!";
                // send cms to admin
                // await cms({name: guest.name, phone: guest.phone, value: guest.value});
                await email.send(guest);
            }
        } catch (e) {
            console.log(e);
        }

        await next();
    }
};

// const __export = require("../Lib/export");
// __export(require("./user"));