'use strict'

var koa = require('koa');
var body = require('koa-better-body');
var convert = require('koa-convert');


const app = new koa();

app.use(convert(body()));

require('./engine.js').Map(app);

app.listen(3009);