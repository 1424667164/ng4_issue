"use strict";

const __export = require("./Lib/export");

let walk = require('walk');
let path = require("path");
var Koa66 = require("koa-66");
var routes = new Array();
let Models = {};

function Router(config) {
    return function (target, key, descriptor) {
        routes.push({ path: config.path, method: config.method, callback: descriptor.value });
        return descriptor;
    };
}
module.exports.Router = Router;
function Map(app) {
    app.use(async (ctx, next) => {
        ctx.set('Access-Control-Allow-Origin', '*');
        ctx.set('Access-Control-Allow-Headers', 'content-type');
        try {
            ctx.body = {
                message: 'start \n',
                status: false,
                code: 0
            }
            await next(); // next is now a function
        } catch (err) {
            ctx.body = {
                message: err.message,
                code: err.code
            };
            console.log(err);
            ctx.status = err.status || 500;
        }
    });
    WalkModels();
    app.use(async (ctx, next) => {  // model
        ModelBind(ctx);
        await next();
    });

    var Router = new Koa66();
    routes.forEach(function (r) {
        r.path = r.path || "/";
        r.method = r.method || "POST";
        switch (r.method) {
            case "POST":
                console.log("POST  " + r.path);
                Router.post(r.path, r.callback);
                break;
            case "GET":
                console.log("GET  " + r.path);
                Router.get(r.path, r.callback);
                break;
        }
    });
    app.use(Router.routes());
}
module.exports.Map = Map;

async function WalkModels() {
    let model_root = path.join(__dirname, "Model");
    var walker = walk.walk(model_root, { followLinks: false });
    walker.on('file', function (root, stat, next) {
        if (stat.name != "model.js" && stat.name != "medoo.js") {
            var mf = path.join(root, stat.name);
            let m = require(path.join(mf));
            if (m) {
                Models[stat.name.substr(0, stat.name.length - 3)] = m;
            }
        }
        next();
    });
    walker.on('directory', function (root, stat, next) {
        walk.walk(path.join(root, stat.name), { followLinks: false });
        next();
    });
    let medoo = require("./Model/model.js");
    await medoo.init();
};

function ModelBind(ctx) {
    ctx.model = Models;
}


__export(require("./Router/index"));
